package com.restapi.kafka;

public interface KafkaConstraints {
    String PERSON_TOPIC_VALUE = "person";
     Object BOOTSTRAP_SERVERS = "localhost:9092";
     //String EMAIL_TOPIC_VALUE = "email";
}
